var demo = function(state, action){
switch(action.type){
    case "LOGIN":{
        console.log("here we have to write logic for login")
        state = {...state}
        state["isloggedin"] = true
        state["user"] = action.payload
        return state
    }
    default : return state
}
}
export default demo