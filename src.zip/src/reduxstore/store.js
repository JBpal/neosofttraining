/* import { getMaxListeners } from 'node:process'
import {createStore} from 'redux'
import demo from "./reducers"
var store = createStore(demo)
store.dispatch({
    type:"login"
})
console.log("............", store.getState())
store.dispatch({
    type:"LOGIN"
    payload:{email:"jpal1988@gmail.com", name:"jb"}
})

console.log("............. after login match", store.getState())

export default store */