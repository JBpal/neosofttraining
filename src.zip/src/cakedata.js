export default [
  {
    name: "Chocolate Cheese Cake",
    price: 1300,
    image:
      "https://res.cloudinary.com/ashudev/image/upload/v1615286247/kzzsqvp1ydkrnat07zjr.jpg",
    cakeid: 1615286283621,
  },
  {
    name: "Chocolate Cake",
    price: 400,
    image:
      "https://res.cloudinary.com/ashudev/image/upload/v1615289983/n8kysvgi6qfubufegavq.jpg",
    cakeid: 1615290293028,
  },
  {
    name: "Chocolava Special",
    price: 5000,
    image:
      "https://res.cloudinary.com/ashudev/image/upload/v1615290519/tot4h3zt8czwo8lmv7sk.jpg",
    cakeid: 1615290595858,
  },
  {
    price: 800,
    name: "Chocolate Truffle",
    image:
      "https://res.cloudinary.com/ashudev/image/upload/v1615290706/gxduqcqyytdvsmsiczcr.jpg",
    cakeid: 1615290710603,
  },
  {
    image:
      "https://res.cloudinary.com/ashudev/image/upload/v1615290731/wsdezq5cchpmddj4n8hd.jpg",
    name: "Chocolate Cake",
    price: 700,
    cakeid: 1615290773495,
  },
  {
    name: "chocolate cake",
    image:
      "https://res.cloudinary.com/ashudev/image/upload/v1615291039/t3mbcsju6gco2ctiyzcg.jpg",
    price: 599,
    cakeid: 1615291050771,
  },
  {
    name: "chocolate cake",
    image:
      "https://res.cloudinary.com/ashudev/image/upload/v1615291145/sn10s30rjcrpvysgnv85.jpg",
    price: 399,
    cakeid: 1615291152501,
  },
  {
    name: "chocolate cake",
    image:
      "https://res.cloudinary.com/ashudev/image/upload/v1615291145/sn10s30rjcrpvysgnv85.jpg",
    price: 399,
    cakeid: 1615291236063,
  },
  {
    name: "Blue Berry cheese Cake",
    price: 1000,
    image:
      "https://res.cloudinary.com/ashudev/image/upload/v1615291611/d6irltnfa9kknsq9pi1y.jpg",
    cakeid: 1615291650149,
  },
  {
    image:
      "https://res.cloudinary.com/ashudev/image/upload/v1615291844/wkfo2qxgqvl41urnuymc.jpg",
    name: "Strawberry cupcake",
    price: 2000,
    cakeid: 1615291848263,
  },
  {
    image:
      "https://res.cloudinary.com/ashudev/image/upload/v1615292716/matnan3dnvztbpnwgylh.jpg",
    name: "blueberry",
    price: 540,
    cakeid: 1615292723149,
  },
  {
    name: "PineApple",
    price: 450,
    image:
      "https://res.cloudinary.com/ashudev/image/upload/v1615292696/gqblabftbjv6nj7zeail.jpg",
    cakeid: 1615292726129,
  },
  {
    image:
      "https://res.cloudinary.com/ashudev/image/upload/v1615293948/nvtmmgae8zbq2qdwfznc.jpg",
    name: "Black Forest",
    price: 200,
    cakeid: 1615293952882,
  },
  {
    name: "PineApple",
    price: 450,
    image:
      "https://res.cloudinary.com/ashudev/image/upload/v1615294711/iosnnenoqbno1dtg9ana.png",
    cakeid: 1615294727568,
  },
  
];
