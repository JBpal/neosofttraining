function Pagenotfound(){
    return (
        <>
        <p>This page is not available</p>
        </>
    );
}

export default Pagenotfound